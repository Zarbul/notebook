from django.shortcuts import render, render_to_response, get_object_or_404, redirect
from .models import Notes
from django.utils import timezone
from django.contrib import auth
from .forms import NoteForm


# Create your views here.

def home(request):
    notes = Notes.objects.all

    if request.method == "POST":
        form_add = NoteForm(request.POST)
        if form_add.is_valid():
            post = form_add.save(commit=False)
            post.create_date = timezone.now()
            post.save()
            return redirect('home')
    else:
        form_add = NoteForm()

    content = {
        'form': form_add,
        'notes': notes,
    }
    return render(request, 'note/index.html', content)


def detail(request, id=None):
    instance = get_object_or_404(Notes, id=id)
    content = {
        'name': instance.name,
        'link': instance.link,
        'instance': instance,
        'text': instance.text,
        'username': auth.get_user(request).username,
    }
    return render(request, 'note/detail.html', content)


def edit(request, id=None):
    note = get_object_or_404(Notes, id=id)
    if request.method == "POST":
        form = NoteForm(request.POST, instance=note)
        if form.is_valid():
            link = form.save(commit=False)
            link.create_date = timezone.now()
            link.save()
            return redirect('home')
    else:
        form = NoteForm(instance=note)
    return render(request, 'note/edit.html', {'form': form})


def delete(request, id=None):
    note = get_object_or_404(Notes, id=id)
    note.delete()
    return redirect('home')

# def new(request, id=None):
#     if request.method == "POST":
#         formWorker = WorkerNameForm(request.POST)
#         formContact = ContactForm(request.POST)
#         if formWorker.is_valid():
#             post = formWorker.save(commit=False)
#             post.create_date = timezone.now()
#             formWorker.save()
#             # return redirect('detail', id=post.id)
#             return redirect('index')
#     else:
#         formWorker = WorkerNameForm()
#         formContact = ContactForm
#
#     content = {
#         'form': formWorker,
#         'contact': formContact,
#         # 'fname': form.fname,
#     }
#     return render(request, 'workers/new.html', content)  # {'form': form})
#
#
