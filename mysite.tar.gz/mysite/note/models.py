from django.db import models
from django.utils import timezone
from django import forms


class Notes(models.Model):
    name = models.CharField('Заголовок', max_length=50)
    link = models.URLField('Ссылка', max_length=100)
    create_date = models.DateTimeField('Дата создания', default=timezone.now)
    # text = models.CharField('Описание', max_length=300)

    #     # status = models.IntegerField(choices=)
    #     balance = models.FloatField('Баланс денег', default = 0)
    #     otdel = models.ForeignKey('otdels.Otdel', default=0)    #
    #     # otd = Otdel()
    #
    class Meta:
        verbose_name = 'Ссылка'
        verbose_name_plural = 'Ссылки'

    def __str__(self):
        return '{} ({})'.format(self.name, self.link, self.create_date)
